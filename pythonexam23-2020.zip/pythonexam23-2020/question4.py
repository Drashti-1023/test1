a  =  input ("enter any sentence :")
b = a.count()
print(b)