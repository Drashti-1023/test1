num = (input ("enter any number :"))
i = num + num
j = num + num + num 
k = num + num + num + num
s = int(i) + int(j) + int(k)
print(s)
