n = input("enter first string: ")
m = input("enter second string: ")

if len(n) == len(m):
	i = n + m 
print(i)