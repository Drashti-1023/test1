""" comma accepting with sorting alphabetically 
"""

text = input("enter any sentence :")
text.sortalpha()
print(text.sortalpha(), end = " , ")
