tuple = (2,3,3,5)
number = int (input("enter a number"))
print(tuple)