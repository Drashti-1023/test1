""" enter a password and check validations 
"""
password = input ("enter your password :")

# if password in [a-z]:
# 	continue
# 	if password in [0-9]:
# 		continue
# 		if password in [A-Z]:
# 			continue
# 			if password in ['$@#']:
# 				continue 
# 				if len(password) <= 6 :
# 					continue
# 					if len(password) <= 12 :
						print(password)


